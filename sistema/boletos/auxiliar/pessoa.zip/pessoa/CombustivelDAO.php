<?php
class CombustivelDAO extends Database{
	
	public function __construct(){
		$this->table = "combustivel";
		parent::__construct();
	}
	
	
	/**
	 *lista todas as marcas cadastradas
	 *
	 * @return Marca[]
	 */
	public function listar(){
		$this->sql = "SELECT * FROM combustivel ORDER BY combustivel";
		$this->values =	array();
		$this->fields = array();
		return parent::fetch();
	}
}
?>