<form action="<?php echo $submit ?>" method="post">
    senha atual: <input type="password" name="senhaAtual"/><br/>
    nova senha: <input type="password" name="novaSenha" /><br/>
    confirme: <input type="password" name="confirmacao"/><br/>
    <input type="submit" value="trocar" name="submit"/>
</form>